import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class panel extends JPanel implements MouseListener,ActionListener{
		JButton b[];
		String index[];
		JPanel board,status;
		Color oc;
		int i=0,j=0;
		char Player='1';		
		JButton pbhr;
		panel()
		{
			board=new JPanel();
			status=new JPanel();
			setLayout(null);
			board.setBounds(0,0,700,700);
			board.setLayout(new GridLayout(8,8));
			b=new JButton[64];
			index=new String[64];
			for(char a='a';a<='h';a++,j++)
			{
				for(char A='A';A<='H';A++,i++,j++)
				{	
					b[i]=new JButton();
					
					if(j%2==0)b[i].setBackground(Color.black);
					else b[i].setBackground(Color.WHITE);
					
					if(i<16&&i>7)b[i].setIcon(new ImageIcon("icons/player2/bp.gif"));
					if(i<56&&i>47)b[i].setIcon(new ImageIcon("icons/player1/wp.gif"));
					b[i].addMouseListener(this);	
					b[i].setName(""+i);
					index[i]=""+a+A;
					System.out.printf("%s  ",index[i]);
					board.add(b[i]);
				}	
					System.out.printf("\n");
			}
			// rook
			b[35].setIcon(new ImageIcon("icons/player2/br.gif"));
			b[7].setIcon(new ImageIcon("icons/player2/br.gif"));
			b[56].setIcon(new ImageIcon("icons/player1/wr.gif"));
			b[63].setIcon(new ImageIcon("icons/player1/wr.gif"));
			// nigth
			b[1].setIcon(new ImageIcon("icons/player2/bn.gif"));
			b[6].setIcon(new ImageIcon("icons/player2/bn.gif"));
			b[57].setIcon(new ImageIcon("icons/player1/wn.gif"));
			b[62].setIcon(new ImageIcon("icons/player1/wn.gif"));
			// bishoop
			b[2].setIcon(new ImageIcon("icons/player2/bb.gif"));
			b[5].setIcon(new ImageIcon("icons/player2/bb.gif"));
			b[58].setIcon(new ImageIcon("icons/player1/wb.gif"));
			b[61].setIcon(new ImageIcon("icons/player1/wb.gif"));
			// King & queen
			b[3].setIcon(new ImageIcon("icons/player2/bq.gif"));
			b[4].setIcon(new ImageIcon("icons/player2/bk.gif"));
			b[59].setIcon(new ImageIcon("icons/player1/wq.gif"));
			b[60].setIcon(new ImageIcon("icons/player1/wk.gif"));
			add(board);
			add(status);
			board();
			
	}
	void board()
	{
		for(int i=0,j=0;i<b.length;i++,j++)
		{
			
					if(j%2==0)b[i].setBackground(Color.black);
					else b[i].setBackground(Color.WHITE);
					if((i+1)%8==0)j++;
					// b[i].removeActionListener(this);
					// b[i].removeMouseListener(this);
					// if(b[i].getIcon()!=null)
						// if((""+b[i].getIcon()).charAt(13)==Player)
							// b[i].addMouseListener(this);	
		}
	}
	int u=0;
	public void mouseClicked(MouseEvent e)
	{
			System.out.println("Pressed...");
			JButton b1=(JButton)e.getSource();
			// board();
			// pbhr=(JButton)e.getSource();
			String icon=""+b1.getIcon();
			int loc=Integer.parseInt(b1.getName());
			char c=index[loc].charAt(1),r=index[loc].charAt(0);
			
			// if(oc==Color.BLACK)
			// {
				// System.out.println("oc="+oc);
			// }
			// if(oc==Color.WHITE)
			// {
				// System.out.println("oc="+oc);
			// }
			
			if(icon.charAt(16)==("icons/player2/br.gif").charAt(16))
			{
				System.out.println(r);
				System.out.println(c);
				System.out.println(icon);
				System.out.println(loc);
					
				for(int i=loc;i<56;i+=8){
					if(b[i+8].getIcon()==null)
					{
						b[i+8].setBackground(Color.GREEN);
						b[i+8].addActionListener(this);
					}
					else if(Player!=(""+b[i+8].getIcon()).charAt(2))
					{
						b[i+8].setBackground(Color.GREEN);
						b[i+8].addActionListener(this);
						break;
					}
					else
						break;
				}
				// for(int i=loc;i>7;i-=8)
				// {
					// if(b[i-8].getIcon()==null)
					// {
						// b[i-8].setBackground(Color.GREEN);
						// b[i-8].addActionListener(this);
					// }
					// else if(Player!=(""+b[i-8].getIcon()).charAt(2))
					// {
						// b[i-8].setBackground(Color.GREEN);
						// b[i-8].addActionListener(this);
						// break;
					// }
					// else
						// break;
				// }
				// for(int i=loc;i<(((loc/8)+1)*8)-1&&b[i+1].getIcon()==null;i++)
				// for(int i=loc;i<63&&r==index[i+1].charAt(0);i++)
				// {
					// if(b[i+1].getIcon()==null)
					// {
						// b[i+1].setBackground(Color.GREEN);
						// b[i+1].addActionListener(this);
					// }
					// else if(Player!=(""+b[i+1].getIcon()).charAt(2))
					// {
						// b[i+1].setBackground(Color.GREEN);
						// b[i+1].addActionListener(this);
						// break;
					// }
					// else
						// break;
				// }
				// for(int i=loc;i>((loc/8)*8)&&b[i-1].getIcon()==null;i--)
				// for(int i=loc;i>0&&r==index[i-1].charAt(0);i--)
				// {
					// if(b[i-1].getIcon()==null)
					// {
						// b[i-1].setBackground(Color.GREEN);
						// b[i-1].addActionListener(this);
					// }
					// else if(Player!=(""+b[i+1].getIcon()).charAt(2))
					// {
						// b[i-1].setBackground(Color.GREEN);
						// b[i-1].addActionListener(this);
						// break;
					// }
					// else
						// break;
				// }
			// }
			// if(icon.charAt(16)==("icons/player2/bb.gif").charAt(16))
			// {
				// System.out.println(icon);
				// System.out.println(loc);
				// for(int i=loc;i<56&&c<index[i+9].charAt(1);i+=9)
				// {
						// if(b[i+9].getIcon()==null)
					// {
						// b[i+9].setBackground(Color.GREEN);
						// b[i+9].addActionListener(this);
					// }
					// else if(Player!=(""+b[i+9].getIcon()).charAt(2))
					// {
						// b[i+9].setBackground(Color.GREEN);
						// b[i+9].addActionListener(this);
						// break;
					// }
					// else
						// break;
				// }
				// for(int i=loc;i<56&&c>index[i+7].charAt(1);i+=7)
				// {
					// if(b[i+7].getIcon()==null)
					// {
						// b[i+7].setBackground(Color.GREEN);
						// b[i+7].addActionListener(this);
					// }
					// else if(Player!=(""+b[i+7].getIcon()).charAt(2))
					// {
						// b[i+7].setBackground(Color.GREEN);
						// b[i+7].addActionListener(this);
						// break;
					// }
					// else
						// break;
				// }
				// for(int i=loc;i>8&&c<index[i-7].charAt(1);i-=7)
				// {
					// if(b[i-7].getIcon()==null)
					// {
						// b[i-7].setBackground(Color.GREEN);
						// b[i-7].addActionListener(this);
					// }
					// else if(Player!=(""+b[i-7].getIcon()).charAt(2))
					// {
						// b[i-7].setBackground(Color.GREEN);
						// b[i-7].addActionListener(this);
						// break;
					// }
					// else
						// break;
				// }
				// for(int i=loc;i>8&&c>index[i-9].charAt(1);i-=9)
				// {
					
					// if(b[i-9].getIcon()==null)
					// {
						// b[i-9].setBackground(Color.GREEN);
						// b[i-9].addActionListener(this);
					// }
					// else if(Player!=(""+b[i-9].getIcon()).charAt(2))
					// {
						// b[i-9].setBackground(Color.GREEN);
						// b[i-9].addActionListener(this);
						// break;
					// }
					// else
						// break;
				// }
			// }
			// if(icon.charAt(1)==("bn2.gif").charAt(1))
			// {
				// if(c<'H'&&r<'g')
				// {
					// if(b[loc+17].getIcon()==null)
					// {
						// b[loc+17].setBackground(Color.GREEN);
						// b[loc+17].addActionListener(this);
					// }
					// else if(Player!=(""+b[i+17].getIcon()).charAt(2))
					// {
						// b[loc+17].setBackground(Color.GREEN);
						// b[loc+17].addActionListener(this);
					// }
				// }
				// if(r<'g'&&c>'A')
				// {
					// if(b[loc+15].getIcon()==null)
					// {
						// b[loc+15].setBackground(Color.GREEN);
						// b[loc+15].addActionListener(this);
					// }
					// else if(Player!=(""+b[i+15].getIcon()).charAt(2))
					// {
						// b[loc+15].setBackground(Color.GREEN);
						// b[loc+15].addActionListener(this);
					// }
				// }
				// if(c<'H'&&r>'b'&&b[loc-15].getIcon()==null)
				// {
					// if(b[i+15].getIcon()==null)
					// {
						// b[loc+15].setBackground(Color.GREEN);
						// b[loc+15].addActionListener(this);
					// }
					// else if(Player!=(""+b[i+15].getIcon()).charAt(2))
					// {
						// b[loc+15].setBackground(Color.GREEN);
						// b[loc+15].addActionListener(this);
					// }
					// b[loc-15].setBackground(Color.GREEN);
					// b[loc-15].addActionListener(this);
				// }
				// if(c>'A'&&r>'b'&&b[loc-17].getIcon()==null){
					// b[loc-17].setBackground(Color.GREEN);
					// b[loc-17].addActionListener(this);}
				// if(r>'a'&&c>'B'&&b[loc-10].getIcon()==null){
					// b[loc-10].setBackground(Color.GREEN);
					// b[loc-10].addActionListener(this);}
				// if(r>'a'&&c<'G'&&b[loc-6].getIcon()==null){
					// b[loc-6].setBackground(Color.GREEN);
					// b[loc-6].addActionListener(this);}
				// if(r<'h'&&c<'G'&&b[loc+10].getIcon()==null){
					// b[loc+10].setBackground(Color.GREEN);
				// b[loc+10].addActionListener(this);}
				// if(r<'h'&&c>'B'&&b[loc+6].getIcon()==null){
					// b[loc+6].setBackground(Color.GREEN);
				// b[loc+6].addActionListener(this);}
			// }
			// if(icon.charAt(1)==("bq2.gif").charAt(1))
			// {
				// for(int i=loc;i<56&& b[i+8].getIcon()==null;i+=8 )
				// {	
					// b[i+8].setBackground(Color.GREEN);
					// b[i+8].addActionListener(this);
				// }
				// for(int i=loc;i>7&& b[i-8].getIcon()==null;i-=8 )
				// {
					// b[i-8].setBackground(Color.GREEN);
					// b[i-8].addActionListener(this);
				// }
				// for(int i=loc;i<(((loc/8)+1)*8)-1&&b[i+1].getIcon()==null;i++)
				// {
					// b[i+1].setBackground(Color.GREEN);
					// b[i+1].addActionListener(this);
				// }
				// for(int i=loc;i>((loc/8)*8)&&b[i-1].getIcon()==null;i--)
				// {
					// b[i-1].setBackground(Color.GREEN);
					// b[i-1].addActionListener(this);
				// }
				// for(int i=loc;i<56&&c<index[i+9].charAt(1)&&b[i+9].getIcon()==null;i+=9)
				// {
					// b[i+9].setBackground(Color.GREEN);
					// b[i+9].addActionListener(this);
				// }
				// for(int i=loc;i<56&&c>index[i+7].charAt(1)&&b[i+7].getIcon()==null;i+=7)
				// {
					// b[i+7].setBackground(Color.GREEN);
					// b[i+7].addActionListener(this);
				// }
				// for(int i=loc;i>8&&c<index[i-7].charAt(1)&&b[i-7].getIcon()==null;i-=7)
				// {
					// b[i-7].setBackground(Color.GREEN);
					// b[i-7].addActionListener(this);
				// }
				// for(int i=loc;i>8&&c>index[i-9].charAt(1)&&b[i-9].getIcon()==null;i-=9)
				// {	
					// b[i-9].setBackground(Color.GREEN);
					// b[i-9].addActionListener(this);
				// }	
			// }
			// if(icon.charAt(1)==("bk2.gif").charAt(1))
			// {
				// System.out.println(c);
				// System.out.println(loc);
				// if(c>'A'&&b[loc-1].getIcon()==null)
				// {
					// b[loc-1].setBackground(Color.GREEN);
					// b[loc-1].addActionListener(this);
				// }
				// if(c<'H'&&b[loc+1].getIcon()==null)
				// {
					// b[loc+1].setBackground(Color.GREEN);
					// b[loc+1].addActionListener(this);
				// }
				// if(r<'h'&&b[loc+8].getIcon()==null)
				// {
					// b[loc+8].setBackground(Color.GREEN);
					// b[loc+8].addActionListener(this);
				// }
				// if(c<'G'&&r<'h'&&b[loc+9].getIcon()==null)
				// {
					// b[loc+9].setBackground(Color.GREEN);
					// b[loc+9].addActionListener(this);
				// }
				// if(c>'A'&&r<'h'&&b[loc+7].getIcon()==null)
				// {	
					// b[loc+7].setBackground(Color.GREEN);
					// b[loc+7].addActionListener(this);
				// }
				// if(c<'G'&&r>'a'&&b[loc-7].getIcon()==null)
				// {
					// b[loc-7].setBackground(Color.GREEN);
					// b[loc-7].addActionListener(this);
				// }
				// if(r>'a'&&b[loc-8].getIcon()==null)
				// {
					// b[loc-8].setBackground(Color.GREEN);
					// b[loc-8].addActionListener(this);
				// }
				// if(c>'A'&&r>'a'&&b[loc-9].getIcon()==null)
				// {
					// b[loc-9].setBackground(Color.GREEN);
					// b[loc-9].addActionListener(this);
				// }
			// }
			// if(icon.charAt(0)==("bp2.gif").charAt(0)&&icon.charAt(1)==("bp2.gif").charAt(1))
			// {
				// if(r=='b')
				// {
					// if(b[loc+8].getIcon()==null)
					// {
					// b[loc+8].setBackground(Color.GREEN);
					// b[loc+8].addActionListener(this);
						// if(b[loc+16].getIcon()==null)
						// {
						// b[loc+16].setBackground(Color.GREEN);
						// b[loc+16].addActionListener(this);
						// }
					// }
				// }
				// else if(r<'h'&&b[loc+8].getIcon()==null){
					// b[loc+8].setBackground(Color.GREEN);
					// b[loc+8].addActionListener(this);
				// }
			// }
			// if(icon.charAt(0)==("wp1.gif").charAt(0)&&icon.charAt(1)==("wp1.gif").charAt(1))
			// {
				// if(r=='g')
				// {
					// if(b[loc-8].getIcon()==null)
					// {
						// b[loc-8].setBackground(Color.GREEN);
						// b[loc-8].addActionListener(this);
						// if(b[loc-16].getIcon()==null)
						// {
							// b[loc-16].setBackground(Color.GREEN);
							// b[loc-16].addActionListener(this);
						// }
					// }
				// }
				// else if(r>'a'&&b[loc-8].getIcon()==null)
				// {
					// b[loc-8].setBackground(Color.GREEN);
					// b[loc-8].addActionListener(this);
				// }
			// }
	}
	}
	public void actionPerformed(ActionEvent e)
	{
		JButton b1=(JButton)e.getSource();
		if(b1.getIcon()==null)
		{
			b1.setIcon(pbhr.getIcon());
			pbhr.setIcon(null);
			Player=Player=='1'?'2':'1';
			board();
		}
	}
	public void mouseExited(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
	public void mousePressed(MouseEvent e){}
}
class Chess extends JFrame{
	panel p;
	Chess(){
	p=new panel();	
	add(p);
	}
public static void main(String...ar){
Chess c=new Chess();
c.setUndecorated(true);
c.setVisible(true);
c.setLocation(300,10);
c.setSize(1000,1000);
}
}