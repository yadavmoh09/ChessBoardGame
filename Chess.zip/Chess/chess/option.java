import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class option extends JFrame implements ActionListener
{
	JButton b1,b2,b3,b4,holder;
	option(JButton temp,char player)
	{
		holder=temp;
    setUndecorated(true);
	setLocationRelativeTo(temp);
	setVisible(true);
	setSize(500,300);
	setLayout(new FlowLayout());
	// setBackground(Color.BLACK);
	getContentPane().setBackground(Color.black);
	b1=new JButton();
	b2=new JButton();
	b3=new JButton();
	b4=new JButton();
	System.out.println(player);
	System.out.println(player!='1');
	if(player!='1')
	{
	b1.setIcon(new ImageIcon("wq1.gif"));
	b2.setIcon(new ImageIcon("wr1.gif"));
	b3.setIcon(new ImageIcon("wn1.gif"));
	b4.setIcon(new ImageIcon("wb1.gif"));
	}
	else
	{
	b1.setIcon(new ImageIcon("bq2.gif"));
	b2.setIcon(new ImageIcon("br2.gif"));
	b3.setIcon(new ImageIcon("bn2.gif"));
	b4.setIcon(new ImageIcon("bb2.gif"));
	}
	b1.setBackground(Color.BLACK);
	b2.setBackground(Color.BLACK);
	b3.setBackground(Color.BLACK);
	b4.setBackground(Color.BLACK);
	b1.setBorderPainted(false);
	b2.setBorderPainted(false);
	b3.setBorderPainted(false);
	b4.setBorderPainted(false);
	add(b1);
	add(b2);
	add(b3);
	add(b4);
	pack();
	b1.addActionListener(this);
	b2.addActionListener(this);
	b3.addActionListener(this);
	b4.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e)
	{
		JButton prev=(JButton)e.getSource();
		  holder.setIcon(prev.getIcon());
		  dispose();
	}
}