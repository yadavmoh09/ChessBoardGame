import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class panel extends JPanel implements MouseListener,ActionListener{
		JButton b[];
		String index[];
		JPanel board,status,right,wp,bp,upper,side;
		JLabel ls[];
		// Color oc;
		int i=0,j=0;
		char Player='1';		
		int loc;
		JLabel cs,lm;
		JButton pbhr;
		Font f1,f2;
		JButton f21[];

		panel()
		{
			board=new JPanel();
			upper=new JPanel();
			side=new JPanel();
			f1=new Font("Impact",Font.BOLD,30);
			f2=new Font("Impact",Font.BOLD,20);
			// upper.setBackground(Color.red);
			// upper.setBounds(180,0,650,30);
			// side.setBackground(Color.red);
			// side.setBounds(150,0,30,680);
			// side.setFont(f1);
			// side.setLayout(null);
			int x=0,y=0,i=0;
			// for(char c='a';c<'h';c++)
			// {
			// ls[i]=new JLabel(""+c);
            // ls[i].setBounds(x,y,30,30);
            // side.add(ls[i]);
             // y+=50;
			 // ++i;
			// }			 
			status=new JPanel();
			status.setFont(f1);	
			wp=new JPanel();
			bp=new JPanel();
			right=new JPanel();
			status.setLayout(new BoxLayout(status,BoxLayout.Y_AXIS));
			cs=new JLabel("Current Move");
			lm=new JLabel("NO move yet");
			setLayout(null);
			status.setBackground(new Color(199,199,199));
			wp.setBackground(new Color(255,255,255));
			bp.setBackground(new Color(255,255,255));
			// board.setSize(700,700);
			// board.setLocationRelativeTo(true);
			board.setBounds(0,0,700,700);
			right.setBounds(700,0,300,700);
			right.setLayout(new GridLayout(3,1));
			board.setLayout(new GridLayout(8,8));
			b=new JButton[64];
			index=new String[64];
			for(char a='a';a<='h';a++,j++)
			{
				for(char A='A';A<='H';A++,i++,j++)
				{	
					b[i]=new JButton();
					
					if(j%2==0)b[i].setBackground(Color.black);
					else b[i].setBackground(Color.WHITE);
					if(i<16&&i>7)b[i].setIcon(new ImageIcon("bp2.gif"));
					if(i<56&&i>47)b[i].setIcon(new ImageIcon("wp1.gif"));
					b[i].addMouseListener(this);
					b[i].setName(""+i);
					index[i]=""+a+A;
					board.add(b[i]);
				}	
			}
			// rook
			b[0].setIcon(new ImageIcon("br2.gif"));
			b[7].setIcon(new ImageIcon("br2.gif"));
			b[56].setIcon(new ImageIcon("wr1.gif"));
			b[63].setIcon(new ImageIcon("wr1.gif"));
			// nigth
			b[1].setIcon(new ImageIcon("bn2.gif"));
			b[6].setIcon(new ImageIcon("bn2.gif"));
			b[57].setIcon(new ImageIcon("wn1.gif"));
			b[62].setIcon(new ImageIcon("wn1.gif"));
			// bishoop
			b[2].setIcon(new ImageIcon("bb2.gif"));
			b[5].setIcon(new ImageIcon("bb2.gif"));
			b[58].setIcon(new ImageIcon("wb1.gif"));
			b[61].setIcon(new ImageIcon("wb1.gif"));
			// King & queen
			b[3].setIcon(new ImageIcon("bq2.gif"));
			b[4].setIcon(new ImageIcon("bk2.gif"));
			b[59].setIcon(new ImageIcon("wq1.gif"));
			// b[60].setIcon(new ImageIcon("wk1.gif"));
			status.add(lm);
			status.add(cs);
			right.add(bp);
			right.add(status);
			right.add(wp);
			add(board);
			// add(side);
			// add(upper);
			add(right);
			board();
			
	}
	void board()
	{
		for(int i=0;i<b.length;i++,j++)
		{
			
					if(j%2==0)b[i].setBackground(Color.black);
					else b[i].setBackground(Color.WHITE);
					if((i+1)%8==0)j++;
					Check(Player,i);
					/*romove Listener*/
					b[i].removeActionListener(this);
					b[i].removeMouseListener(this);
 
					/*Add Listener*/
					if(b[i].getIcon()!=null)
						if((""+b[i].getIcon()).charAt(2)==Player)
							b[i].addMouseListener(this);	
		}
		cs.setFont(f2);
		if(Player=='1')
			cs.setText("current Move: White");
		else
			cs.setText("current Move: Black");
	}
	int u=0;
	public void mouseClicked(MouseEvent e)
	{
			System.out.println("Pressed...");
			JButton b1=(JButton)e.getSource();
			board();
			pbhr=(JButton)e.getSource();
			String icon=""+b1.getIcon();
			loc=Integer.parseInt(b1.getName());
			char c=index[loc].charAt(1),r=index[loc].charAt(0);
			
			// if(oc==Color.BLACK)
			// {
				// System.out.println("oc="+oc);
			// }
			// if(oc==Color.WHITE)
			// {
				// System.out.println("oc="+oc);
			// }
			
			if(icon.charAt(1)==("br2.gif").charAt(1))
			{
					
				for(int i=loc;i<56;i+=8){
					if(b[i+8].getIcon()==null)
					{
						b[i+8].setBackground(Color.GREEN);
						b[i+8].addActionListener(this);
					}
					else if(Player!=(""+b[i+8].getIcon()).charAt(2))
					{
						b[i+8].setBackground(Color.GREEN);
						b[i+8].addActionListener(this);
						break;
					}
					else
						break;
				}
				for(int i=loc;i>7;i-=8)
				{
					if(b[i-8].getIcon()==null)
					{
						b[i-8].setBackground(Color.GREEN);
						b[i-8].addActionListener(this);
					}
					else if(Player!=(""+b[i-8].getIcon()).charAt(2))
					{
						b[i-8].setBackground(Color.GREEN);
						b[i-8].addActionListener(this);
						break;
					}
					else
						break;
				}
				for(int i=loc;i<(((loc/8)+1)*8)-1;i++)
				// for(int i=loc;i<63&&r==index[i+1].charAt(0);i++)
				{
					if(b[i+1].getIcon()==null)
					{
						b[i+1].setBackground(Color.GREEN);
						b[i+1].addActionListener(this);
					}
					else if(Player!=(""+b[i+1].getIcon()).charAt(2))
					{
						b[i+1].setBackground(Color.GREEN);
						b[i+1].addActionListener(this);
						break;
					}
					else
						break;
				}
				for(int i=loc;i>((loc/8)*8);i--)
				// for(int i=loc;i>0&&r==index[i-1].charAt(0);i--)
				{
					if(b[i-1].getIcon()==null)
					{
						b[i-1].setBackground(Color.GREEN);
						b[i-1].addActionListener(this);
					}
					else if(Player!=(""+b[i-1].getIcon()).charAt(2))
					{
						b[i-1].setBackground(Color.GREEN);
						b[i-1].addActionListener(this);
						break;
					}
					else
						break;
				}
			}
			if(icon.charAt(1)==("bb2.gif").charAt(1))
			{
				System.out.println(icon);
				System.out.println(loc);
				for(int i=loc;i<56&&c<index[i+9].charAt(1);i+=9)
				{	
						if(b[i+9].getIcon()==null)
					{
						b[i+9].setBackground(Color.GREEN);
						b[i+9].addActionListener(this);
					}
					else if(Player!=(""+b[i+9].getIcon()).charAt(2))
					{
						b[i+9].setBackground(Color.GREEN);
						b[i+9].addActionListener(this);
						break;
					}
					else
						break;
				}
				for(int i=loc;i<56&&c>index[i+7].charAt(1);i+=7)
				{
					if(b[i+7].getIcon()==null)
					{
						b[i+7].setBackground(Color.GREEN);
						b[i+7].addActionListener(this);
					}
					else if(Player!=(""+b[i+7].getIcon()).charAt(2))
					{
						b[i+7].setBackground(Color.GREEN);
						b[i+7].addActionListener(this);
						break;
					}
					else
						break;
				}
				for(int i=loc;i>8&&c<index[i-7].charAt(1);i-=7)
				{
					if(b[i-7].getIcon()==null)
					{
						b[i-7].setBackground(Color.GREEN);
						b[i-7].addActionListener(this);
					}
					else if(Player!=(""+b[i-7].getIcon()).charAt(2))
					{
						b[i-7].setBackground(Color.GREEN);
						b[i-7].addActionListener(this);
						break;
					}
					else
						break;
				}
				for(int i=loc;i>8&&c>index[i-9].charAt(1);i-=9)
				{
					
					if(b[i-9].getIcon()==null)
					{
						b[i-9].setBackground(Color.GREEN);
						b[i-9].addActionListener(this);
					}
					else if(Player!=(""+b[i-9].getIcon()).charAt(2))
					{
						b[i-9].setBackground(Color.GREEN);
						b[i-9].addActionListener(this);
						break;
					}
					else
						break;
				}
			}
			if(icon.charAt(1)==("bn2.gif").charAt(1))
			{
				if(c<'H'&&r<'g')
				{
					if(b[loc+17].getIcon()==null)
					{
						b[loc+17].setBackground(Color.GREEN);
						b[loc+17].addActionListener(this);
					}
					else if(Player!=(""+b[loc+17].getIcon()).charAt(2))
					{
						b[loc+17].setBackground(Color.GREEN);
						b[loc+17].addActionListener(this);
					}
				}
				if(r<'g'&&c>'A')
				{
					if(b[loc+15].getIcon()==null)
					{
						b[loc+15].setBackground(Color.GREEN);
						b[loc+15].addActionListener(this);
					}
					else if(Player!=(""+b[loc+15].getIcon()).charAt(2))
					{
						b[loc+15].setBackground(Color.GREEN);
						b[loc+15].addActionListener(this);
					}
				}
				if(c<'H'&&r>'b')
				{
					if(b[loc-15].getIcon()==null)
					{
						b[loc-15].setBackground(Color.GREEN);
						b[loc-15].addActionListener(this);
					}
					else if(Player!=(""+b[loc-15].getIcon()).charAt(2))
					{
						b[loc-15].setBackground(Color.GREEN);
						b[loc-15].addActionListener(this);
					}
				}
				if(c>'A'&&r>'b'&&b[loc-17].getIcon()==null)
				{
					
					if(b[loc-17].getIcon()==null)
					{
					b[loc-17].setBackground(Color.GREEN);
					b[loc-17].addActionListener(this);
					}
					else if(Player!=(""+b[loc-17].getIcon()).charAt(2))
					{
						b[loc-17].setBackground(Color.GREEN);
						b[loc-17].addActionListener(this);
					}
				}
				if(r>'a'&&c>'B')
				{
					if(b[loc-10].getIcon()==null)
					{
					b[loc-10].setBackground(Color.GREEN);
					b[loc-10].addActionListener(this);
					}
					else if(Player!=(""+b[loc-10].getIcon()).charAt(2))
					{
						b[loc-10].setBackground(Color.GREEN);
						b[loc-10].addActionListener(this);
					}
				}
				if(r>'a'&&c<'G')
				{
					
					if(b[loc-6].getIcon()==null)
					{
						b[loc-6].setBackground(Color.GREEN);
						b[loc-6].addActionListener(this);
					}
					else if(Player!=(""+b[loc-6].getIcon()).charAt(2))
					{
						b[loc-6].setBackground(Color.GREEN);
						b[loc-6].addActionListener(this);
					}
				}
				if(r<'h'&&c<'G')
				{
					
					if(b[loc+10].getIcon()==null)
					{
						b[loc+10].setBackground(Color.GREEN);
						b[loc+10].addActionListener(this);
					}
					else if(Player!=(""+b[loc+10].getIcon()).charAt(2))
					{
						b[loc+10].setBackground(Color.GREEN);
						b[loc+10].addActionListener(this);
					}
				}
				if(r<'h'&&c>'B'&&b[loc+6].getIcon()==null)
				{
					
					if(b[loc+10].getIcon()==null)
					{
						b[loc+6].setBackground(Color.GREEN);
						b[loc+6].addActionListener(this);
					}
					else if(Player!=(""+b[loc+10].getIcon()).charAt(2))
					{
						b[loc+6].setBackground(Color.GREEN);
						b[loc+6].addActionListener(this);
					}
				}
			}
			if(icon.charAt(1)==("bq2.gif").charAt(1))
			{
				for(int i=loc;i<56;i+=8){
					if(b[i+8].getIcon()==null)
					{
						b[i+8].setBackground(Color.GREEN);
						b[i+8].addActionListener(this);
					}
					else if(Player!=(""+b[i+8].getIcon()).charAt(2))
					{
						b[i+8].setBackground(Color.GREEN);
						b[i+8].addActionListener(this);
						break;
					}
					else
						break;
				}
				for(int i=loc;i>7;i-=8)
				{
					if(b[i-8].getIcon()==null)
					{
						b[i-8].setBackground(Color.GREEN);
						b[i-8].addActionListener(this);
					}
					else if(Player!=(""+b[i-8].getIcon()).charAt(2))
					{
						b[i-8].setBackground(Color.GREEN);
						b[i-8].addActionListener(this);
						break;
					}
					else
						break;
				}
				for(int i=loc;i<(((loc/8)+1)*8)-1;i++)
				// for(int i=loc;i<63&&r==index[i+1].charAt(0);i++)
				{
					if(b[i+1].getIcon()==null)
					{
						b[i+1].setBackground(Color.GREEN);
						b[i+1].addActionListener(this);
					}
					else if(Player!=(""+b[i+1].getIcon()).charAt(2))
					{
						b[i+1].setBackground(Color.GREEN);
						b[i+1].addActionListener(this);
						break;
					}
					else
						break;
				}
				for(int i=loc;i>((loc/8)*8);i--)
				// for(int i=loc;i>0&&r==index[i-1].charAt(0);i--)
				{
					if(b[i-1].getIcon()==null)
					{
						b[i-1].setBackground(Color.GREEN);
						b[i-1].addActionListener(this);
					}
					else if(Player!=(""+b[i-1].getIcon()).charAt(2))
					{
						b[i-1].setBackground(Color.GREEN);
						b[i-1].addActionListener(this);
						break;
					}
					else
						break;
				}
				for(int i=loc;i<54&&c<index[i+9].charAt(1);i+=9)
				{
					if(b[i+9].getIcon()==null)
					{
						b[i+9].setBackground(Color.GREEN);
						b[i+9].addActionListener(this);
					}
					else if(Player!=(""+b[i+9].getIcon()).charAt(2))
					{
						b[i+9].setBackground(Color.GREEN);
						b[i+9].addActionListener(this);
						break;
					}
					else
						break;
				}
				for(int i=loc;i<56&&c>index[i+7].charAt(1);i+=7)
				{
					if(b[i+7].getIcon()==null)
					{
						b[i+7].setBackground(Color.GREEN);
						b[i+7].addActionListener(this);
					}
					else if(Player!=(""+b[i+7].getIcon()).charAt(2))
					{
						b[i+7].setBackground(Color.GREEN);
						b[i+7].addActionListener(this);
						break;
					}
					else
						break;
				}
				for(int i=loc;i>8&&c<index[i-7].charAt(1);i-=7)
				{
					if(b[i-7].getIcon()==null)
					{
						b[i-7].setBackground(Color.GREEN);
						b[i-7].addActionListener(this);
					}
					else if(Player!=(""+b[i-7].getIcon()).charAt(2))
					{
						b[i-7].setBackground(Color.GREEN);
						b[i-7].addActionListener(this);
						break;
					}
					else
						break;
				}
				for(int i=loc;i>8&&c>index[i-9].charAt(1);i-=9)
				{
					
					if(b[i-9].getIcon()==null)
					{
						b[i-9].setBackground(Color.GREEN);
						b[i-9].addActionListener(this);
					}
					else if(Player!=(""+b[i-9].getIcon()).charAt(2))
					{
						b[i-9].setBackground(Color.GREEN);
						b[i-9].addActionListener(this);
						break;
					}
					else
						break;
				}
			}
			if(icon.charAt(1)==("bk2.gif").charAt(1))
			{
				if(c>'A')
				{
					if(b[loc-1].getIcon()==null)
					{
						b[loc-1].setBackground(Color.GREEN);
						b[loc-1].addActionListener(this);
					}
					else if(Player!=(""+b[loc-1].getIcon()).charAt(2))
					{
						b[loc-1].setBackground(Color.GREEN);
						b[loc-1].addActionListener(this);
					}
				}
				if(c<'H')
				{
					if(b[loc+1].getIcon()==null)
					{
						b[loc+1].setBackground(Color.GREEN);
						b[loc+1].addActionListener(this);
					}
					else if(Player!=(""+b[loc+1].getIcon()).charAt(2))
					{
						b[loc+1].setBackground(Color.GREEN);
						b[loc+1].addActionListener(this);
					}
				}
				if(r<'h')
				{
					if(b[loc+8].getIcon()==null)
					{
						b[loc+8].setBackground(Color.GREEN);
						b[loc+8].addActionListener(this);
					}
					else if(Player!=(""+b[loc+8].getIcon()).charAt(2))
					{
						b[loc+8].setBackground(Color.GREEN);
						b[loc+8].addActionListener(this);
					}
				}
				if(c<'G'&&r<'h')
				{
					
					if(b[loc+9].getIcon()==null)
					{
						b[loc+9].setBackground(Color.GREEN);
						b[loc+9].addActionListener(this);
					}
					else if(Player!=(""+b[loc+9].getIcon()).charAt(2))
					{
						b[loc+9].setBackground(Color.GREEN);
						b[loc+9].addActionListener(this);
					}
				}
				if(c>'A'&&r<'h')
				{	
					if(b[loc+7].getIcon()==null)
					{
						b[loc+7].setBackground(Color.GREEN);
						b[loc+7].addActionListener(this);
					}
					else if(Player!=(""+b[loc+7].getIcon()).charAt(2))
					{
						b[loc+7].setBackground(Color.GREEN);
						b[loc+7].addActionListener(this);
					}
				}
				if(c<'G'&&r>'a')
				{
					if(b[loc-7].getIcon()==null)
					{
						b[loc-7].setBackground(Color.GREEN);
						b[loc-7].addActionListener(this);
					}
					else if(Player!=(""+b[loc-7].getIcon()).charAt(2))
					{
						b[loc-7].setBackground(Color.GREEN);
						b[loc-7].addActionListener(this);
					}
				}
				if(r>'a')
				{
					if(b[loc-8].getIcon()==null)
					{
						b[loc-8].setBackground(Color.GREEN);
						b[loc-8].addActionListener(this);
					}
					else if(Player!=(""+b[loc-8].getIcon()).charAt(2))
					{
						b[loc-8].setBackground(Color.GREEN);
						b[loc-8].addActionListener(this);
					}
				}
				if(c>'A'&&r>'a')
				{
					if(b[loc-9].getIcon()==null)
					{
						b[loc-9].setBackground(Color.GREEN);
						b[loc-9].addActionListener(this);
					}
					else if(Player!=(""+b[loc-9].getIcon()).charAt(2))
					{
						b[loc-9].setBackground(Color.GREEN);
						b[loc-9].addActionListener(this);
					}
				}
			}
			if(icon.charAt(0)==("bp2.gif").charAt(0)&&icon.charAt(1)==("bp2.gif").charAt(1))
			{
				if(r=='b')
				{
					if(b[loc+8].getIcon()==null)
					{
					b[loc+8].setBackground(Color.GREEN);
					b[loc+8].addActionListener(this);
						if(b[loc+16].getIcon()==null)
						{
						b[loc+16].setBackground(Color.GREEN);
						b[loc+16].addActionListener(this);
						}
					}
					if(Player!=(""+b[loc+9].getIcon()).charAt(2)&&(""+b[loc+9].getIcon()).length()>4)
					{
						b[loc+9].setBackground(Color.GREEN);
						b[loc+9].addActionListener(this);
					}
					if(Player!=(""+b[loc+7].getIcon()).charAt(2)&&(""+b[loc+7].getIcon()).length()>4)
					{
						b[loc+7].setBackground(Color.GREEN);
						b[loc+7].addActionListener(this);
					}

				}
				else if(r<'h')
				{
					if(b[loc+8].getIcon()==null)
					{
						b[loc+8].setBackground(Color.GREEN);
						b[loc+8].addActionListener(this);
					}
					if(c!='A'&&Player!=(""+b[loc+7].getIcon()).charAt(2)&&(""+b[loc+7].getIcon()).length()>4)
					{
						b[loc+7].setBackground(Color.GREEN);
						b[loc+7].addActionListener(this);
					}
					if(c!='H'&&Player!=(""+b[loc+9].getIcon()).charAt(2)&&(""+b[loc+9].getIcon()).length()>4)
					{
						b[loc+9].setBackground(Color.GREEN);
						b[loc+9].addActionListener(this);
					}
				}
			}	
			if(icon.charAt(0)==("wp1.gif").charAt(0)&&icon.charAt(1)==("wp1.gif").charAt(1))
			{
				if(r=='g')
				{
					if(b[loc-8].getIcon()==null)
					{
						b[loc-8].setBackground(Color.GREEN);
						b[loc-8].addActionListener(this);
						if(b[loc-16].getIcon()==null)
						{
							b[loc-16].setBackground(Color.GREEN);
							b[loc-16].addActionListener(this);
						}
					}
					if(c>'A'&&Player!=(""+b[loc-9].getIcon()).charAt(2)&&(""+b[loc-9].getIcon()).length()>4)
					{
						b[loc-9].setBackground(Color.GREEN);
						b[loc-9].addActionListener(this);
					}
					if(c<'H'&&Player!=(""+b[loc-7].getIcon()).charAt(2)&&(""+b[loc-7].getIcon()).length()>4)
					{
						b[loc-7].setBackground(Color.GREEN);
						b[loc-7].addActionListener(this);
					}
				}
				else if(r>'a')
				{
					if(b[loc-8].getIcon()==null)
					{
						b[loc-8].setBackground(Color.GREEN);
						b[loc-8].addActionListener(this);
					}
					if(c<'H'&&Player!=(""+b[loc-7].getIcon()).charAt(2)&&(""+b[loc-7].getIcon()).length()>4)
					{
						b[loc-7].setBackground(Color.GREEN);
						b[loc-7].addActionListener(this);
					}
					if(c>'A'&&Player!=(""+b[loc-9].getIcon()).charAt(2)&&(""+b[loc-9].getIcon()).length()>4)
					{
						b[loc-9].setBackground(Color.GREEN);
						b[loc-9].addActionListener(this);
					}
				}
			}
	}
	
	public void Check(char player,int position)
	{
		if(b[position].getIcon()!=null && (""+b[position].getIcon()).charAt(1)==("bk2.gif").charAt(1))
		{
			for(int i=position;i<56 && b[i+8].getIcon()==null || (""+b[i+8].getIcon()).charAt(1)=='r';i+=8)
			{
				if(b[i+8].getIcon()!=null && (""+b[i+8].getIcon()).charAt(1)=='r')
				{
					b[position].setBackground(Color.red);
				}
			}
			
			for(int i=position;i<56 && b[i+7].getIcon()==null || (""+b[i+7].getIcon()).charAt(1)=='b';i+=7)
			{
				if(b[i+7].getIcon()!=null && (""+b[i+7].getIcon()).charAt(1)=='b')
				{
					b[position].setBackground(Color.red);
				}
			}
			if(position<56 && index[position+6].charAt(0)!='h' && index[position+6].charAt(1)>'B')
			{
				if(b[position+6].getIcon()!=null && (""+b[position+6].getIcon()).charAt(1)=='n')
				{
					b[position].setBackground(Color.red);
				}
			}
			
			
		}
	}
	public void actionPerformed(ActionEvent e)
	{
		JButton b1=(JButton)e.getSource();
		option op;
		int l=Integer.parseInt(b1.getName());
		int pl=Integer.parseInt(pbhr.getName());
		char c=index[loc].charAt(1),r=index[loc].charAt(0);
		if(b1.getIcon()==null)
		{
			b1.setIcon(pbhr.getIcon());
			pbhr.setIcon(null);
			Player=Player=='1'?'2':'1';
			board();
		}
		else if(Player!=(""+b1.getIcon()).charAt(2))
		{
                 JLabel lb=new JLabel();
                 lb.setIcon(b1.getIcon());
				 b1.setIcon(pbhr.getIcon());
                 pbhr.setIcon(null); 
                 Player=Player=='1' ? '2' : '1';
				 board();
				 if(Player=='1')
				 {
					 wp.add(lb);
				 }
				 else
				 {
					 bp.add(lb);
 				 }
				 }
				 System.out.println((""+b1.getIcon()).charAt(1));
				   if(index[l].charAt(0)=='a' && (""+b1.getIcon()).charAt(2)!=Player && (""+b1.getIcon()).charAt(1)=='p')
					   op=new option(b1,Player);
				   else if(index[l].charAt(0)=='h' && (""+b1.getIcon()).charAt(2)!=Player&& (""+b1.getIcon()).charAt(1)=='p')
					   op=new option(b1,Player);
					lm.setFont(f1);
                   lm.setText("Last Move: "+index[pl]+" => "+index[l]);
	}
	public void mouseExited(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
	public void mousePressed(MouseEvent e){}
}
class Chess extends JFrame{
	panel p;
	Chess(){
	p=new panel();	
	add(p);
	}
public static void main(String...ar){
Chess c=new Chess();
c.setUndecorated(true);
c.setVisible(true);
c.setLocation(300,10);
c.setSize(1000,1000);
}
}